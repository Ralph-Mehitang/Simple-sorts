Below are the answers to the questions from lab 1

A.
The best case time complexity of a Bubble sort is O(n) while the worst case is O(n^2)
The best case time complexity of an Insertion sort is O(n) while the worst case is O(n^2)
The best case time complexity of a Selection sort is O(n^2) while the worst case is O(n^2)

B.

As the array size increases the run time increases due to the number of elements being higher and the sorting process having to take longer. as to using the data collected to rectify the theoretical time complexity, I do believe that you can do so but I do not necessarily know how to.

C. with each sorts I found that they perfomed relatively similar in terms of time when the arrays were shorter. as the array sizes increased you began to see how each perfomed different 
from one another in terms of the time it took. Selection sort took longer than all the arrays when I jumped from 10 elements in the arrays to 100, 1000 and so forth.

D. With my code I think I could improve my codes usability by making it more easier and straightforward to follow from another developers viewpoint, commenting more etc. In terms of efficiency I think the code I wrote takes up a lot of space and is long and I think
that I could have written alot of it in shorter lenghts .